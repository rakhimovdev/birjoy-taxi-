const express = require("express");
const cors = require("cors");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "client")));

const db = new Database(path.join(__dirname, "taxi.db"));

db.exec(`
CREATE TABLE IF NOT EXISTS drivers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  car TEXT NOT NULL,
  plate TEXT NOT NULL,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  online INTEGER DEFAULT 0,
  lat REAL,
  lng REAL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rides (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  pickup TEXT NOT NULL,
  destination TEXT NOT NULL,
  pickup_lat REAL,
  pickup_lng REAL,
  destination_lat REAL,
  destination_lng REAL,
  price REAL NOT NULL,
  status TEXT DEFAULT 'searching',
  driver_id INTEGER,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(driver_id) REFERENCES drivers(id)
);
`);

const count = db.prepare("SELECT COUNT(*) AS c FROM drivers").get().c;
if (count === 0) {
  db.prepare(`
    INSERT INTO drivers
    (name, phone, car, plate, username, password, online, lat, lng)
    VALUES (?, ?, ?, ?, ?, ?, 0, NULL, NULL)
  `).run("Demo Haydovchi", "+998900000000", "Chevrolet Cobalt", "01 A 123 AA", "driver", "driver123");
}

function estimatePrice(pickupLat, pickupLng, destLat, destLng) {
  if ([pickupLat, pickupLng, destLat, destLng].every(v => typeof v === "number" && Number.isFinite(v))) {
    const R = 6371;
    const dLat = (destLat - pickupLat) * Math.PI / 180;
    const dLng = (destLng - pickupLng) * Math.PI / 180;
    const a = Math.sin(dLat/2)**2 +
      Math.cos(pickupLat*Math.PI/180) * Math.cos(destLat*Math.PI/180) *
      Math.sin(dLng/2)**2;
    const km = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return Math.max(10000, Math.round((7000 + km * 2500) / 1000) * 1000);
  }
  return 15000;
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "Bir Joy Taxi API" });
});

app.post("/api/rides", (req, res) => {
  const {
    customer_name, customer_phone, pickup, destination,
    pickup_lat, pickup_lng, destination_lat, destination_lng
  } = req.body;

  if (!customer_name || !customer_phone || !pickup || !destination) {
    return res.status(400).json({ error: "Majburiy maydonlar to'ldirilmagan." });
  }

  const price = estimatePrice(
    Number(pickup_lat), Number(pickup_lng),
    Number(destination_lat), Number(destination_lng)
  );

  const result = db.prepare(`
    INSERT INTO rides
    (customer_name, customer_phone, pickup, destination,
     pickup_lat, pickup_lng, destination_lat, destination_lng, price)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    customer_name, customer_phone, pickup, destination,
    pickup_lat ?? null, pickup_lng ?? null,
    destination_lat ?? null, destination_lng ?? null, price
  );

  res.json({
    success: true,
    ride_id: result.lastInsertRowid,
    price,
    status: "searching"
  });
});

app.get("/api/rides/:id", (req, res) => {
  const ride = db.prepare(`
    SELECT rides.*, drivers.name AS driver_name, drivers.phone AS driver_phone,
           drivers.car AS driver_car, drivers.plate AS driver_plate,
           drivers.lat AS driver_lat, drivers.lng AS driver_lng
    FROM rides
    LEFT JOIN drivers ON drivers.id = rides.driver_id
    WHERE rides.id = ?
  `).get(req.params.id);

  if (!ride) return res.status(404).json({ error: "Buyurtma topilmadi." });
  res.json(ride);
});

app.get("/api/rides", (req, res) => {
  const rides = db.prepare(`
    SELECT rides.*, drivers.name AS driver_name, drivers.car AS driver_car,
           drivers.plate AS driver_plate
    FROM rides
    LEFT JOIN drivers ON drivers.id = rides.driver_id
    ORDER BY rides.id DESC
  `).all();
  res.json(rides);
});

app.post("/api/driver/login", (req, res) => {
  const { username, password } = req.body;
  const driver = db.prepare(`
    SELECT id, name, phone, car, plate, online, lat, lng
    FROM drivers WHERE username = ? AND password = ?
  `).get(username, password);

  if (!driver) return res.status(401).json({ error: "Login yoki parol noto'g'ri." });
  res.json(driver);
});

app.post("/api/driver/:id/status", (req, res) => {
  const { online, lat, lng } = req.body;
  db.prepare(`
    UPDATE drivers SET online = ?, lat = ?, lng = ? WHERE id = ?
  `).run(online ? 1 : 0, lat ?? null, lng ?? null, req.params.id);

  res.json({ success: true });
});

app.get("/api/driver/:id/rides", (req, res) => {
  const rides = db.prepare(`
    SELECT * FROM rides
    WHERE driver_id = ? OR (status = 'searching' AND driver_id IS NULL)
    ORDER BY id DESC
  `).all(req.params.id);
  res.json(rides);
});

app.post("/api/rides/:id/accept", (req, res) => {
  const { driver_id } = req.body;
  const driver = db.prepare("SELECT * FROM drivers WHERE id = ?").get(driver_id);
  if (!driver) return res.status(404).json({ error: "Haydovchi topilmadi." });

  const result = db.prepare(`
    UPDATE rides
    SET driver_id = ?, status = 'accepted'
    WHERE id = ? AND status = 'searching' AND driver_id IS NULL
  `).run(driver_id, req.params.id);

  if (result.changes === 0) {
    return res.status(409).json({ error: "Buyurtma allaqachon qabul qilingan yoki mavjud emas." });
  }

  res.json({ success: true });
});

app.post("/api/rides/:id/status", (req, res) => {
  const allowed = ["accepted", "arriving", "started", "completed", "cancelled"];
  const { status } = req.body;

  if (!allowed.includes(status)) {
    return res.status(400).json({ error: "Noto'g'ri status." });
  }

  db.prepare("UPDATE rides SET status = ? WHERE id = ?").run(status, req.params.id);
  res.json({ success: true });
});

app.get("/api/drivers", (req, res) => {
  const drivers = db.prepare(`
    SELECT id, name, phone, car, plate, online, lat, lng, created_at
    FROM drivers ORDER BY id DESC
  `).all();
  res.json(drivers);
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "client", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Bir Joy Taxi server: http://localhost:${PORT}`);
});
