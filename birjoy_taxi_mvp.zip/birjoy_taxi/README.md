# Bir Joy Taxi — Online Taxi MVP

Bu loyiha online taxi xizmatining boshlang'ich ishlaydigan versiyasi:
- Mijoz: taxi buyurtma qiladi
- Haydovchi: online bo'ladi va buyurtmani qabul qiladi
- Admin: buyurtmalarni ko'radi
- Backend: Node.js + Express
- Database: SQLite
- Xarita: Leaflet + OpenStreetMap

## Ishga tushirish

1. Kompyuterga Node.js 20+ o'rnating.
2. Terminalda `server` papkasiga kiring:
   cd server
3. Paketlarni o'rnating:
   npm install
4. Serverni ishga tushiring:
   npm start
5. Brauzerda oching:
   http://localhost:3000

## Demo kirish
Admin:
- Login: admin
- Parol: admin123

Haydovchi demo:
- Login: driver
- Parol: driver123

Mijoz uchun login shart emas — ism va telefon kiritib buyurtma berish mumkin.

## Muhim
Bu MVP. Real biznesga chiqarishdan oldin:
- SMS/OTP
- real GPS tracking
- xavfsiz autentifikatsiya
- online to'lov
- haydovchi hujjatlarini tekshirish
- HTTPS
- production database
- rate limiting
- audit/logging
kabi qismlar qo'shilishi kerak.
