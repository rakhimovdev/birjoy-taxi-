let map;
let driver = null;
let driverOnline = false;

function showPage(id) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  if (id === "customer" && map) setTimeout(() => map.invalidateSize(), 100);
}

document.addEventListener("DOMContentLoaded", () => {
  map = L.map("map").setView([41.3111, 69.2797], 12);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors"
  }).addTo(map);

  document.getElementById("rideForm").addEventListener("submit", createRide);
  document.getElementById("driverLogin").addEventListener("submit", driverLogin);
});

function useMyLocation() {
  if (!navigator.geolocation) {
    alert("Brauzeringiz GPSni qo'llab-quvvatlamaydi.");
    return;
  }

  navigator.geolocation.getCurrentPosition(pos => {
    const lat = pos.coords.latitude;
    const lng = pos.coords.longitude;
    document.getElementById("pickup_lat").value = lat;
    document.getElementById("pickup_lng").value = lng;
    document.getElementById("pickup").value = "Mening joylashuvim";
    map.setView([lat, lng], 15);
    L.marker([lat, lng]).addTo(map).bindPopup("Sizning joylashuvingiz").openPopup();
  }, () => alert("Joylashuvni olishga ruxsat berilmadi."));
}

async function createRide(e) {
  e.preventDefault();

  const body = {
    customer_name: document.getElementById("customer_name").value,
    customer_phone: document.getElementById("customer_phone").value,
    pickup: document.getElementById("pickup").value,
    destination: document.getElementById("destination").value,
    pickup_lat: numberOrNull("pickup_lat"),
    pickup_lng: numberOrNull("pickup_lng"),
    destination_lat: numberOrNull("destination_lat"),
    destination_lng: numberOrNull("destination_lng")
  };

  const r = await fetch("/api/rides", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(body)
  });
  const data = await r.json();

  if (!r.ok) return alert(data.error || "Xatolik yuz berdi.");

  document.getElementById("rideResult").innerHTML = `
    <div class="result">
      <b>Buyurtma qabul qilindi!</b><br>
      Buyurtma №: ${data.ride_id}<br>
      Taxminiy narx: <b>${formatMoney(data.price)} so'm</b><br>
      Holat: <span id="customerStatus">Haydovchi qidirilmoqda...</span>
    </div>
  `;

  watchRide(data.ride_id);
}

function numberOrNull(id) {
  const v = document.getElementById(id).value;
  return v === "" ? null : Number(v);
}

function formatMoney(v) {
  return new Intl.NumberFormat("uz-UZ").format(v);
}

async function watchRide(id) {
  const timer = setInterval(async () => {
    const r = await fetch(`/api/rides/${id}`);
    if (!r.ok) return;
    const ride = await r.json();

    const status = document.getElementById("customerStatus");
    if (!status) return clearInterval(timer);

    const labels = {
      searching: "Haydovchi qidirilmoqda...",
      accepted: "Haydovchi buyurtmani qabul qildi.",
      arriving: "Haydovchi siz tomonga kelyapti.",
      started: "Safar boshlandi.",
      completed: "Safar yakunlandi.",
      cancelled: "Buyurtma bekor qilindi."
    };
    status.textContent = labels[ride.status] || ride.status;

    if (ride.driver_name) {
      status.innerHTML += `<br>Haydovchi: <b>${ride.driver_name}</b> — ${ride.driver_car || ""} ${ride.driver_plate || ""}`;
    }

    if (["completed", "cancelled"].includes(ride.status)) clearInterval(timer);
  }, 3000);
}

async function driverLogin(e) {
  e.preventDefault();

  const r = await fetch("/api/driver/login", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      username: document.getElementById("driver_username").value,
      password: document.getElementById("driver_password").value
    })
  });

  const data = await r.json();
  if (!r.ok) return alert(data.error);

  driver = data;
  driverOnline = !!data.online;

  document.getElementById("driverLogin").hidden = true;
  document.getElementById("driverPanel").hidden = false;
  renderDriverInfo();
  loadDriverRides();
}

function renderDriverInfo() {
  document.getElementById("driverInfo").innerHTML = `
    <div class="result">
      <b>${driver.name}</b><br>
      ${driver.car} — ${driver.plate}<br>
      Holat: <b>${driverOnline ? "ONLINE" : "OFFLINE"}</b>
    </div>
  `;
}

async function toggleDriver() {
  if (!driver) return;

  driverOnline = !driverOnline;
  let lat = null, lng = null;

  if (driverOnline && navigator.geolocation) {
    try {
      const pos = await new Promise((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject)
      );
      lat = pos.coords.latitude;
      lng = pos.coords.longitude;
    } catch {}
  }

  await fetch(`/api/driver/${driver.id}/status`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ online: driverOnline, lat, lng })
  });

  renderDriverInfo();
  loadDriverRides();
}

async function loadDriverRides() {
  if (!driver) return;
  const r = await fetch(`/api/driver/${driver.id}/rides`);
  const rides = await r.json();

  const html = rides.map(x => `
    <div class="item">
      <b>Buyurtma #${x.id}</b><br>
      ${x.pickup} → ${x.destination}<br>
      ${formatMoney(x.price)} so'm<br>
      Status: <span class="status">${x.status}</span>
      ${x.status === "searching" && driverOnline
        ? `<button class="primary" onclick="acceptRide(${x.id})">Qabul qilish</button>`
        : ""}
      ${x.driver_id == driver.id && x.status === "accepted"
        ? `<button class="primary" onclick="setRideStatus(${x.id}, 'arriving')">Mijoz tomonga yo'l olish</button>`
        : ""}
      ${x.driver_id == driver.id && x.status === "arriving"
        ? `<button class="primary" onclick="setRideStatus(${x.id}, 'started')">Safarni boshlash</button>`
        : ""}
      ${x.driver_id == driver.id && x.status === "started"
        ? `<button class="primary" onclick="setRideStatus(${x.id}, 'completed')">Safarni tugatish</button>`
        : ""}
    </div>
  `).join("");

  document.getElementById("driverRides").innerHTML = html || "<p>Buyurtmalar yo'q.</p>";
}

async function acceptRide(id) {
  const r = await fetch(`/api/rides/${id}/accept`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({driver_id: driver.id})
  });
  const data = await r.json();
  if (!r.ok) alert(data.error);
  loadDriverRides();
}

async function setRideStatus(id, status) {
  const r = await fetch(`/api/rides/${id}/status`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({status})
  });
  const data = await r.json();
  if (!r.ok) alert(data.error);
  loadDriverRides();
}

async function loadAdmin() {
  const [ridesR, driversR] = await Promise.all([
    fetch("/api/rides"),
    fetch("/api/drivers")
  ]);

  const rides = await ridesR.json();
  const drivers = await driversR.json();

  document.getElementById("adminRides").innerHTML = rides.map(x => `
    <div class="item">
      <b>#${x.id}</b> — ${x.customer_name} (${x.customer_phone})<br>
      ${x.pickup} → ${x.destination}<br>
      ${formatMoney(x.price)} so'm — <b>${x.status}</b><br>
      Haydovchi: ${x.driver_name || "hali biriktirilmagan"}
    </div>
  `).join("") || "<p>Buyurtmalar yo'q.</p>";

  document.getElementById("adminDrivers").innerHTML = drivers.map(x => `
    <div class="item">
      <b>${x.name}</b> — ${x.car} — ${x.plate}<br>
      ${x.phone} — ${x.online ? "ONLINE" : "OFFLINE"}
    </div>
  `).join("");
}
